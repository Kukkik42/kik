﻿using System.Reflection;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("GitExtensions")]
[assembly: AssemblyDescription("GitExtensions is a graphical interface for Git")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("GitExtensions")]
[assembly: AssemblyProduct("GitExtensions")]
[assembly: AssemblyCopyright("Copyright © 2008-2017 GitExt Team")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("2.50.02")]
[assembly: AssemblyFileVersion("2.50.02")]
[assembly: AssemblyInformationalVersion("2.50.02")]

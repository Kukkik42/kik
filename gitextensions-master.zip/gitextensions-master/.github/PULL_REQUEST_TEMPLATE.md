Fixes # .

Changes proposed in this pull request:
 - 
 - 
 - 
 
Screenshots before and after (if PR changes UI):
-
-
-

How did I test this code:
 - 
 - 
 - 

Has been tested on (remove any that don't apply):
 - GIT 2.10 and above
 - Windows 7 and above

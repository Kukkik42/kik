﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
[assembly: System.CLSCompliant(false)]

﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: System.CLSCompliant(false)]
[assembly: InternalsVisibleTo("GitPluginShared")]

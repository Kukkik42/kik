﻿using ResourceManager;

namespace GitUI.CommandsDialogs
{
    public partial class FormCommandlineHelp : GitExtensionsForm
    {
        public FormCommandlineHelp()
        {
            InitializeComponent(); Translate();
        }
    }
}

namespace GitCommands
{
    public enum BranchOrdering
    {
        ByLastAccessDate = 0,
        Alphabetically = 1,
    }
}
﻿namespace GitCommands.Repository
{
    public enum RepositoryType
    {
        Repository,
        RssFeed,
        History
    }
}
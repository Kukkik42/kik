﻿namespace GitCommands.Repository
{
    public enum RepositoryCategoryType
    {
        Repositories,
        RssFeed
    }
}
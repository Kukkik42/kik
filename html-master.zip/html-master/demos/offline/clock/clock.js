/* clock.js */
setInterval(function () {
    document.getElementById('clock').value = new Date();
}, 1000);

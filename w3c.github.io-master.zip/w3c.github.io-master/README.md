
# The W3C organisation

This is the repository for the documentation that sits at [https://w3c.github.io/](https://w3c.github.io).

## Directories
Directories (e.g., "DOM-Level-3-Events-key") are repositories that have been renamed. These serve as redirects.

All documents in this Repository are licensed by contributors
under the
[W3C Software and Document License](http://www.w3.org/Consortium/Legal/copyright-software).


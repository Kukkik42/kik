# W3C Process Document repository

This repository is for the editor's draft of the [World Wide Web Consortium Process Document](https://www.w3.org/Consortium/Process/)

The Process document is updated most years by the W3C.

The editor's draft is now available at https://w3c.github.io/w3process/
